﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfMashine.Classes;

namespace WpfMashine.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddDrink.xaml
    /// </summary>
    public partial class PageAddDrink : Page
    {
        private Drinks _currentItem = new Drinks();
        public PageAddDrink(Drinks selectedItem)
        {
            InitializeComponent();
            if (selectedItem != null)
            {
                _currentItem = selectedItem;
                Titletxt.Text = "Изменение напитка";
                BtnAdd.Content = "Изменить";
            }
            DataContext = _currentItem;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.Name))) error.AppendLine("Укажите название");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.Price))) error.AppendLine("Укажите цену");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentItem.id_drinks == 0)
            {
                DrinkmashineEntities.GetContext().Drinks.Add(_currentItem);
                try
                {
                    DrinkmashineEntities.GetContext().SaveChanges();
                    ClassFrame.frmObj.Navigate(new PageDrinks());
                    MessageBox.Show("Новый напиток успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    DrinkmashineEntities.GetContext().SaveChanges();
                    ClassFrame.frmObj.Navigate(new PageDrinks());
                    MessageBox.Show("Напиток успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageDrinks());
        }
    }
}
