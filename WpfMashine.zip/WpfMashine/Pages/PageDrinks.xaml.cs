﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfMashine.Classes;

namespace WpfMashine.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageDrinks.xaml
    /// </summary>
    public partial class PageDrinks : Page
    {
        public PageDrinks()
        {
            InitializeComponent();
            dtgComp.ItemsSource = DrinkmashineEntities.GetContext().Drinks.ToList();
            int count = 0;
            prcieall.Text = count.ToString();
        }
        private void btnTo1_Click(object sender, RoutedEventArgs e)
        {
            int summa = 1 + int.Parse(prcieall.Text);
            prcieall.Text = summa.ToString();
        }

        private void btnTo2_Click(object sender, RoutedEventArgs e)
        {
            int summa = 2 + int.Parse(prcieall.Text);
            prcieall.Text = summa.ToString();
        }

        private void btnTo5_Click(object sender, RoutedEventArgs e)
        {
            int summa = 5 + int.Parse(prcieall.Text);
            prcieall.Text = summa.ToString();
        }

        private void btnTo10_Click(object sender, RoutedEventArgs e)
        {
            int summa = 10 + int.Parse(prcieall.Text);
            prcieall.Text = summa.ToString();
        }

        private void MenuAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddDrink(null));
        }

        private void MenuEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddDrink((Drinks)dtgComp.SelectedItem));
        }

        private void MenuDel_Click(object sender, RoutedEventArgs e)
        {
            var salesForRemoving = dtgComp.SelectedItems.Cast<Drinks>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {salesForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    DrinkmashineEntities.GetContext().Drinks.RemoveRange(salesForRemoving);
                    DrinkmashineEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    dtgComp.ItemsSource = DrinkmashineEntities.GetContext().Drinks.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void btnToback_Click(object sender, RoutedEventArgs e)
        {
            Drinks sale = (Drinks)dtgComp.SelectedItem;
            if (int.Parse(prcieall.Text) >= sale.Price)
            {
                int count = (int)(int.Parse(prcieall.Text) - sale.Price);
                prcieall.Text = count.ToString();
                MessageBox.Show("Вы успешно приобрели товар!");
            }
            else
            {
                MessageBox.Show("Недостаточно средств!");
            }
        }
    }
}
